// Stripeの決済ページにリダイレクトさせつつセッションIDを送信する処理
const stripe = Stripe('pk_test_51P2TiABdKu1HyQmamv9tlCQ2YeCohtYe50tsBi8919H6dPgwyeD6CGYAxMx7fRBEbRTTR5fifrygoxC2HUq8s7Oo00O3zMWmoL');
 const paymentButton = document.querySelector('#paymentButton');
 
 paymentButton.addEventListener('click', () => {
   stripe.redirectToCheckout({
     sessionId: sessionId
   })
 });